function displayDate() {
    alert('This is the date template')
}

function displayTime() {
    alert('This is the time template')
}